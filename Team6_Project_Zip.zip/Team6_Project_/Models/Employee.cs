﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Team6_Project_.Models
{
    public class Employee
    {
        public int Id { get; set; }
        public string EmpName { get; set; }
        public int Salary { get; set; }
    }
}
